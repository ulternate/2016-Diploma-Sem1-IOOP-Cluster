# KFL-Android-App
Android app for www.kfl.com.au

- Enables users to login and see their player roster and see/edit their team selection for the round.
- They can also see the latest articles from www.kfl.com.au without being logged in.

Application is available here: [Google Play Store Link](https://play.google.com/store/apps/details?id=com.danielcswain.kfl)
